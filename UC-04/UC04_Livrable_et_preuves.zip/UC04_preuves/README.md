# UC-04 - preuves et livrable

Ce paquet contient UC04_NiFi_Ingestion.pdf et UC04_preuves/.

Capture réellement fournie : provenance/05_provenance_nifi.png.

À ajouter depuis votre poste :
- configuration/01_pipeline_nifi.png
- configuration/02_getfile_properties.png
- configuration/03_puthdfs_properties.png
- execution/04_execution_nifi.png
- hdfs/06_hdfs_store.png
- hdfs/07_sha256.png
- erreurs/08_pipeline_test_erreur.png
- erreurs/09_journal_conflit.png

Le test d'erreur réalisé est un conflit de nom dans HDFS. Le TP suggère à l'étape 10 un dossier source absent ou illisible : ne pas confondre ces deux scénarios.
