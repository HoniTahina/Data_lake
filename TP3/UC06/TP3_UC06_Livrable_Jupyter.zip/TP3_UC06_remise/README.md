# Retail Intelligence Platform - TP3 / UC-06

## Contenu de cette remise
- `notebooks/TP3_Retail_Intelligence_execute.ipynb` : notebook Jupyter transmis, avec sorties d'exécution sauvegardées (12 cellules de code exécutées).
- `scripts/TP3_UC06_export_notebook.py` : export des cellules de code du notebook ; **ne remplace pas** les scripts individuels `01_...` à `13_...` présents sur le PC utilisateur.
- `docs/rapport_UC06_TP3.pdf` : rapport de synthèse et limites méthodologiques.
- `docs/regles_nettoyage.md` : transformations et décisions.
- `dictionnaire/colonnes_item_store_sales_reference_UC01.csv` : extrait du dictionnaire de référence UC01 (à confronter au schéma officiel).
- `quality/resultats_controles_valides.json` : résultats rapportés et reproduits dans le notebook.
- `preuves/synthese_sorties_notebook.txt` : résumé textuel vérifiable dans le notebook.

## Reproduire dans Ubuntu WSL
1. Activer l'environnement Python : `source ~/environnements/retail-tp3/bin/activate`.
2. Définir Java : `export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64`.
3. Vérifier Hadoop : `hdfs dfs -ls /retail-lake/raw/nifi/store.dat`.
4. Lancer : `jupyter lab`.
5. Ouvrir le notebook avec le noyau de l'environnement. Démarrer avec les cellules dans l'ordre.
6. Le notebook réutilise les sorties Silver et Gold existantes ; il ne les écrase pas. Pour une reconstruction de zéro, les scripts d'origine présents sur le PC, les sources HDFS et une stratégie de remise à zéro/renommage sont nécessaires. **Ne pas supprimer les données HDFS par défaut.**

## Limites de cette archive
Cette archive a été construite à partir du notebook joint, du dictionnaire UC01 disponible et des résultats communiqués. Elle n'inclut pas les 978 Mo de sources sur le PC, les fichiers Parquet HDFS ni les 12 scripts historiques individuellement. Ces fichiers doivent être ajoutés depuis le poste de travail si la remise exige les originaux. Les captures écran natives et journaux externes ne sont pas inclus.
