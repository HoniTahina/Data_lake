# Règles de préparation des données (UC-06)

## Sources et périmètre
Trois tables parmi les 23 fichiers disponibles : `store`, `item`, `store_sales` ; séparateur `|`, sans en-tête. Toutes les données proviennent de la source TPCx-BB synthétique du projet.

## Silver
- `store` : conversion de `_c0` en entier et `_c2` en date ISO ; aucun identifiant/date invalide détecté ; `_c3` conservé NULL.
- `item` et `store_sales` : suppression des espaces en début et en fin de champ ; chaîne vide convertie en NULL ; aucune ligne supprimée.
- Les noms `_cN` et les types chaîne sont majoritairement conservés dans Silver : harmonisation et typage complets non réalisés.
- Doublons **de lignes complètes** : aucun sur les tables vérifiées ; les doublons métier (par ticket, date, clé composite) n'ont pas été audités.

## Jointures et Gold
- `store_sales._c2` → `item._c0` (clé article), `store_sales._c7` → `store._c0` (clé magasin) : unicité des dimensions, 100 % de correspondances pour 667 579 lignes de ventes.
- Selon le dictionnaire de référence TPCx-BB d'UC01, `store_sales._c10` = `ss_quantity`, `_c13` = `ss_sales_price`, `_c15` = `ss_ext_sales_price`, `_c20` = `ss_net_paid`, `_c22` = `ss_net_profit`. Correspondances alignées sur les 23 positions et cohérence empirique quantité × prix = montant.
- Contrôle `ss_quantity × ss_sales_price = ss_ext_sales_price` : zéro écart de plus de 0,01 sur les 667 579 lignes.
- Pas d'exclusion des bénéfices négatifs ; les données TPCx-BB sont synthétiques et l'unité monétaire n'est pas établie.

## Points à traiter
- Réconcilier intégralement les noms et types des 29 colonnes de `store` avec un dictionnaire officiel.
- Mettre en place des tests de valeurs admissibles et de clés métier, notamment les champs NULL, prix et dates.
- Définir une politique de relance : les écritures de scripts historiques sont `errorifexists`, et le notebook contrôle les sorties déjà présentes.
- Prouver un éventuel gain de temps de requête par benchmark séparé ; la réduction de stockage n'en est pas une mesure.
